# FishFood
The life of a fish is hard.
@Author Tyler Whitehurst

This is a small project to further understand javascript.
This game intends to mimick a fish. Remember, though you
may think that fish are friends, some creatures may think
differently. Run from the sharks and make some friends
along your journey.